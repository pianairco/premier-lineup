import {Component, EventEmitter, Input, OnInit, Output, ViewChild} from '@angular/core';
import {MatMenuTrigger} from "@angular/material/menu";
import {MatExpansionPanel} from "@angular/material/expansion";
import {BehaviorSubject} from "rxjs";

@Component({
  selector: 'app-avatar',
  templateUrl: './avatar.component.html',
  styleUrls: ['./avatar.component.css']
})
export class AvatarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  objValue: any = null;
  @ViewChild('menuTrigger') menuTrigger: MatMenuTrigger;
  @ViewChild('mep') mep: MatExpansionPanel;
  imgSubject = new BehaviorSubject(this.objValue);
  @Output() valueChange: EventEmitter<any> = new EventEmitter<any>();
  @Input() uploaderFormats: any;
  @Input() maxWidth: any;
  @Input() maxHeight: any;
  title: string;

  _toggleImageExpand(e) {
    console.log("a1")
    if(this.objValue) {
      this.menuTrigger.openMenu();
      this.mep.toggle();
    } else {
      e.stopPropagation();
    }
  }

  onSelectedFileDelete() {
    console.log("a2")
    this.objValue = null;
    this.imgSubject.next(this.objValue);
  }

  onSelectedFilesChanged(event) {
    console.log(event, event[0])
    if (event && event[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event[0]); // read file as data url

      reader.onload = (event) => { // called once readAsDataURL is completed
        console.log(event, event.target.result)
        this.objValue = event.target.result;
        this.valueChange.emit(this.objValue);
        this.imgSubject.next(this.objValue);
        this.mep.close();
        console.log(this.objValue)
      }
    }
  }

  onUploadClicked(file) {
  }
}
